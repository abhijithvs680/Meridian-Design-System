# Pinned chapters

A sticky chapter heading beside a naturally scrolling narrative.

## Use
Copy the section from the specimen into a `mk-page` wrapper. Load `marketing/marketing.css`. Include `marketing/marketing.js` for disclosure, dialog, form, pricing, gallery or progress controls. Keep the assets in `assets/Marketing` and adjust relative paths when moving the markup.

## Interaction
The heading releases at the end of its section. On narrow screens and reduced motion it uses regular document flow.

## Handoff
Choose a scoped `data-mk-tone`, edit the product content and replace the example destinations. Use one H1 per page and update heading levels when combining sections. Verify keyboard focus, mobile wrapping and reduced motion in the assembled page.
