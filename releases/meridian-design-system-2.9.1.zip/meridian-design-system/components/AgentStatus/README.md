# AgentStatus

A compact pill that says what an agent is doing right now; text shimmer for in-progress labels.

## When to use
Agent panel header, records being worked on, run lists, the top bar while an agent works in the background.

## Anatomy and variants
`.m-agent-status` pill (+ `.is-waiting`, `.is-idle`, `.is-error`) with a pulse, icon or dot and a short present-tense label. `.m-shimmer` animates a label while thinking.

## States
thinking · running (step x of y) · waiting for approval · idle · failed. Shimmer stops under reduced motion.

## Accessibility
Status text is real text in a polite live region; the animation is decorative.

## OpenUI
`AgentStatus(state, label?)`
