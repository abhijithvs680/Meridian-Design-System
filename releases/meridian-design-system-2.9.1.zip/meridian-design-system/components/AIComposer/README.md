# AIComposer

Agent conversation input with files, context controls, and send/stop.

## When to use
Compose a message in an agent workspace.

## Anatomy
Multiline input, attachments, model controls, send/stop.

## Variants
| Variant | Use |
| --- | --- |
| Full | Attachments, context chip, model select, hint line |
| Compact | Inside ChatThread and the agent panel: input + attach + send |
| Inline | Single-line ask bar (StarterPrompts header) |

## States
Designed states: empty, ready, uploading, sending, generating, error.

| State | Treatment |
| --- | --- |
| empty | Placeholder names the agent; Send available but validates |
| ready | Solid agent Send |
| uploading | Attachment chip with spinner; Send waits for uploads |
| sending | Send `aria-busy` |
| generating | Input disabled, AgentStatus "Generating", Stop response replaces Send |
| error | Danger border + one-line reason under the input; text is kept |

## Accessibility and Meridian rules
Visible label or `aria-label` naming the agent; Send and Stop are real buttons; ids are generated per instance; failed attachments say why in text.
Use semantic landmarks, keyboard-reachable actions, plain-text state labels and polite announcements for meaningful changes. Respect reduced motion. Keep Meridian tokens, source and citation details, and the ApprovalCard rule for any external effect.

## Related components
Extends the `.m-composer` from AgentMessage. Use it wherever a user writes to an agent.

## OpenUI
`AIComposer(placeholder?, state?, attachments?, agentName?)`
