"""Reusable original composer structures and upgraded conversation input."""
LAYOUTS = [('workspace','AIComposer','What shall we work on?'),('research','ResearchComposer','Start with a better question.'),('command','CommandComposer','Your next command.'),('brief','BriefComposer','Turn intent into a clear brief.'),('canvas','CanvasComposer','Make room for your next idea.'),('reply','ContextComposer','Continue the conversation.')]

def composer(layout='workspace', title='What shall we work on?'):
    return f'''<form class="mc" data-layout="{layout}" aria-label="Agent task composer">
<header class="mc-head"><span class="mc-mark" aria-hidden="true">◈</span><div><strong>Meridian Assistant</strong><small>Your workspace, in context</small></div><span class="mc-private">Local preview</span></header>
<h2 class="mc-title">{title}</h2><aside class="mc-context"><strong>Working context</strong>South collections · 4 accounts · aging report</aside>
<div class="mc-prompts"><button type="button" data-prompt="Compare overdue accounts and explain the changes.">↗ Compare accounts</button><button type="button" data-prompt="Draft a concise follow-up for the overdue accounts.">✎ Draft a follow-up</button><button type="button" data-prompt="Create a plan to resolve outstanding balances.">☷ Build a plan</button></div>
<div class="mc-editor"><div class="mc-files" aria-label="Attached files"></div><textarea aria-label="Describe your task" placeholder="Ask a question, describe a task, or bring an idea…" rows="3"></textarea><input type="file" multiple hidden aria-label="Choose attachments">
<div class="mc-toolbar"><button type="button" class="mc-tool" data-attach aria-label="Attach files">＋</button><button type="button" class="mc-tool" data-context aria-pressed="true">◫ Context</button><select name="mode" aria-label="Task mode"><option>Ask</option><option>Plan</option><option>Draft</option></select><select name="model" aria-label="Model preference"><option>Balanced</option><option>Fast</option><option>Deep reasoning</option></select><button class="mc-send" type="submit">Run task ↑</button></div></div>
<div class="mc-foot"><span>Enter to run · Shift + Enter for a new line</span><span>Actions require your application's permissions</span></div><p class="mc-status" role="status" aria-live="polite">Demo · no model connected</p></form>'''

def build_composers(write, root, version):
    import re,json
    markup={}
    for layout,name,title in LAYOUTS:
        body=composer(layout,title);markup[name]=body
        write(f'components/{name}/preview.html',f'''<!-- @dsCard group="Agent" height=680 -->
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{name} · Meridian</title><link rel="stylesheet" href="../composer.css?v={version}"></head><body class="mc-demo"><p class="mc-demo-label">Meridian / Agent interfaces / {layout}</p>{body}<script src="../composer.js?v={version}"></script></body></html>''')
        write(f'components/{name}/README.md',f'''# {name}\n\nA {layout} composer with editable prompts, removable file attachments, context, task mode and model preference.\n\nLoad `components/composer.css` and `components/composer.js`. Listen for the bubbling `meridian:compose` CustomEvent: `detail` contains text, File objects, model, mode and context. The built-in adapter is a local preview, not an AI backend. Replace the demo timer with your runtime and enforce permissions server-side. Attachment contents are never read by the demo. Enter submits; Shift+Enter adds a line; IME composition is preserved. Empty submissions are disabled; Stop preserves the draft.\n''')
    path=root/'components/ChatThread/preview.html'
    source=path.read_text(encoding='utf-8')
    source=re.sub(r'<form class="(?:m-ai-composer|mc)".*?</form>',composer('reply'),source,flags=re.S)
    if '../composer.css' not in source: source=source.replace('</head>',f'<link rel="stylesheet" href="../composer.css?v={version}"></head>').replace('</body>',f'<script src="../composer.js?v={version}"></script></body>')
    write('components/ChatThread/preview.html',source)
    write('catalog/composer-markup.js','window.MERIDIAN_COMPOSERS = '+json.dumps(markup)+';\n')
