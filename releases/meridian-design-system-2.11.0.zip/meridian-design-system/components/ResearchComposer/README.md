# ResearchComposer

A research composer with editable prompts, removable file attachments, context, task mode and model preference.

Load `components/composer.css` and `components/composer.js`. Listen for the bubbling `meridian:compose` CustomEvent: `detail` contains text, File objects, model, mode and context. The built-in adapter is a local preview, not an AI backend. Replace the demo timer with your runtime and enforce permissions server-side. Attachment contents are never read by the demo. Enter submits; Shift+Enter adds a line; IME composition is preserved. Empty submissions are disabled; Stop preserves the draft.
