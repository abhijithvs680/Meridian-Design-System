/* Local demo adapter. Listen for meridian:compose to integrate your runtime. */
(() => {
  function init(root=document) {
    root.querySelectorAll('.mc').forEach(form => {
      if(form.dataset.ready)return; form.dataset.ready='true';
      const input=form.querySelector('textarea'), send=form.querySelector('.mc-send'), status=form.querySelector('.mc-status'), files=form.querySelector('input[type=file]'), tray=form.querySelector('.mc-files');
      let attachments=[], busy=false, timer;
      const update=()=>{send.disabled=!busy&&!input.value.trim();};
      const drawFiles=()=>{tray.replaceChildren();attachments.forEach((file,index)=>{const chip=document.createElement('span');chip.className='mc-file';chip.append(document.createTextNode(file.name));const remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.setAttribute('aria-label','Remove '+file.name);remove.onclick=()=>{attachments.splice(index,1);drawFiles();};chip.append(remove);tray.append(chip);});};
      form.querySelector('[data-attach]').onclick=()=>files.click();
      files.onchange=()=>{attachments.push(...files.files);drawFiles();files.value='';status.textContent='Files staged locally. Nothing has been uploaded.';};
      form.querySelectorAll('[data-prompt]').forEach(button=>button.onclick=()=>{input.value=button.dataset.prompt;input.focus();update();});
      form.querySelector('[data-context]').onclick=event=>{const button=event.currentTarget;const active=button.getAttribute('aria-pressed')!=='true';button.setAttribute('aria-pressed',String(active));form.querySelector('.mc-context').hidden=!active;};
      input.addEventListener('input',update);
      input.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();if(!send.disabled)form.requestSubmit();}});
      form.addEventListener('submit',event=>{event.preventDefault();if(busy){clearTimeout(timer);busy=false;send.textContent='Run task ↑';status.textContent='Demo stopped. Your draft is preserved.';update();return;}if(!input.value.trim())return;
        form.dispatchEvent(new CustomEvent('meridian:compose',{bubbles:true,detail:{text:input.value,files:[...attachments],model:form.querySelector('[name=model]').value,mode:form.querySelector('[name=mode]').value,context:form.querySelector('[data-context]').getAttribute('aria-pressed')==='true'}}));
        busy=true;send.textContent='Stop ■';status.textContent='Previewing the handoff…';update();
        timer=setTimeout(()=>{busy=false;send.textContent='Run task ↑';status.textContent='Task payload prepared. Connect meridian:compose to your agent runtime to execute it. No AI request was sent.';update();},1100);
      });update();
    });
  }
  window.MeridianComposer={init};init();
})();
