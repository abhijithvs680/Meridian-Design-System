(() => {
  const data = window.MERIDIAN_CATALOG;
  const $ = id => document.getElementById(id);
  const dialog = $('preview-dialog'); const frame = $('preview-frame'); let selected; let returnFocus;
  const text = (tag, value, className) => { const el=document.createElement(tag); el.textContent=value; if(className) el.className=className; return el; };
  $('component-count').textContent = $('stat-components').textContent = data.components.length;
  $('asset-count').textContent = $('stat-assets').textContent = data.assets.length;
  [...new Set(data.components.map(c=>c.group))].sort().forEach(group=>{const o=text('option',group);o.value=group;$('category').append(o);});
  function renderComponents() {
    const query=$('search').value.trim().toLowerCase(), category=$('category').value;
    const items=data.components.filter(c=>(category==='all'||c.group===category)&&(!$('new-only').checked||c.added)&&`${c.name} ${c.summary} ${c.group}`.toLowerCase().includes(query));
    $('component-grid').replaceChildren();
    items.forEach(c=>{
      const b=document.createElement('button'); b.className='component-tile'; b.type='button';
      const top=text('div','', 'tile-top');top.append(text('span',c.group));if(c.added) top.append(text('span','NEW','new'));
      b.append(top,text('strong',c.name),text('p',c.summary),text('span','Preview component ↗','tile-arrow'));
      b.addEventListener('click',()=>openPreview(c));$('component-grid').append(b);
    });
    $('result-count').textContent=items.length ? `${items.length} components · Select a component to inspect its preview.` : 'No matches. Try another term or clear the filters.';
  }
  ['search','category','new-only'].forEach(id=>$(id).addEventListener('input',renderComponents));renderComponents();
  data.patterns.forEach((p,i)=>{const a=document.createElement('a');a.className='pattern-tile';a.href=p.path;a.target='_blank';a.rel='noopener';a.append(text('span',`0${i+1}`,'pattern-number'),text('h2',p.name),text('p',p.components.join(' · ')),text('span','Open page pattern ↗','card-link'));$('pattern-grid').append(a);});
  function renderAssets(){
    $('asset-grid').replaceChildren();
    data.assets.filter(a=>$('asset-group').value==='all'||a.group===$('asset-group').value).forEach(a=>{const tile=document.createElement('article');tile.className='asset-tile';tile.dataset.group=a.group;const img=document.createElement('img');img.src=a.path;img.alt='';img.loading='lazy';const download=text('a','Download SVG ↗');download.href=a.path;download.download=a.name+'.svg';tile.append(img,text('strong',a.name),download);$('asset-grid').append(tile);});
  }$('asset-group').addEventListener('change',renderAssets);renderAssets();
  ['bg','surface','surface-sunken','fg','fg-muted','primary','agent','success','warning','danger','border','focus'].forEach(token=>{const c=document.createElement('div');c.className='token';const swatch=document.createElement('div');swatch.style.background=`var(--${token})`;c.append(swatch,text('strong',`--${token}`),text('p',token.replaceAll('-',' ')));$('token-grid').append(c);});
  function syncFrame(){try{const html=frame.contentDocument?.documentElement;if(!html)return;html.dataset.theme=document.documentElement.dataset.theme;html.dataset.density=document.documentElement.dataset.density||'';html.dir=document.documentElement.dir||'ltr';}catch{ /* file:// may restrict cross-document access */ }}
  frame.addEventListener('load',syncFrame);
  $('theme').addEventListener('click',()=>{const dark=document.documentElement.dataset.theme!=='dark';document.documentElement.dataset.theme=dark?'dark':'light';$('theme').setAttribute('aria-pressed',String(dark));$('theme').textContent=dark?'Light theme':'Dark theme';syncFrame();});
  $('density').addEventListener('click',()=>{const compact=document.documentElement.dataset.density!=='compact';document.documentElement.dataset.density=compact?'compact':'';$('density').setAttribute('aria-pressed',String(compact));syncFrame();});
  $('direction').addEventListener('click',()=>{const rtl=document.documentElement.dir!=='rtl';document.documentElement.dir=rtl?'rtl':'ltr';$('direction').setAttribute('aria-pressed',String(rtl));syncFrame();});
  function openPreview(c){selected=c;returnFocus=document.activeElement;$('preview-title').textContent=c.name;$('preview-group').textContent=c.group;$('preview-description').textContent=c.summary;$('open-preview').href=c.path;$('read-docs').href=c.path.replace('preview.html','README.md');$('copy-status').textContent='';frame.src=c.path;frame.style.width='100%';$('preview-wide').setAttribute('aria-pressed','true');$('preview-mobile').setAttribute('aria-pressed','false');dialog.showModal();}
  $('close-preview').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>{frame.src='about:blank';returnFocus?.focus();if(location.hash.startsWith('#preview='))history.replaceState(null,'','#overview');});
  $('preview-wide').addEventListener('click',()=>{frame.style.width='100%';$('preview-wide').setAttribute('aria-pressed','true');$('preview-mobile').setAttribute('aria-pressed','false');});
  $('preview-mobile').addEventListener('click',()=>{frame.style.width='390px';$('preview-wide').setAttribute('aria-pressed','false');$('preview-mobile').setAttribute('aria-pressed','true');});
  $('copy-markup').addEventListener('click',async()=>{try{const content=frame.contentDocument.body.cloneNode(true);content.querySelectorAll('script').forEach(s=>s.remove());content.querySelectorAll('[data-initialized]').forEach(el=>el.removeAttribute('data-initialized'));await navigator.clipboard.writeText(content.innerHTML);$('copy-status').textContent='HTML copied. Include Meridian styles and the relevant controller in your app.';}catch{$('copy-status').textContent='Clipboard access is unavailable here. Open the standalone preview and copy its source, or serve this folder with npm run preview.';}});
  function route(){const key=location.hash.slice(1)||'overview';if(key.startsWith('preview=')){const c=data.components.find(c=>c.name===decodeURIComponent(key.slice(8)));if(c&&!dialog.open)openPreview(c);return;}const id=['overview','components','patterns','assets','foundations'].includes(key)?key:'overview';document.querySelectorAll('.view').forEach(v=>v.hidden=v.id!==id);document.querySelectorAll('[data-section]').forEach(a=>{if(a.dataset.section===id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});$('breadcrumb').textContent=id[0].toUpperCase()+id.slice(1);window.scrollTo(0,0);}
  window.addEventListener('hashchange',route);route();
})();

